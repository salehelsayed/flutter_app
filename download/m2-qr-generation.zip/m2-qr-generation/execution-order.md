# M2 Execution Order

This document shows the recommended order for executing tasks, including which tasks can run in parallel.

---

## Dependency Graph (Visual)

```
PHASE 1: Foundation (Parallel Tracks)
═══════════════════════════════════════════════════════════════════════════════

  JS Track                          Flutter Model Track
  ────────                          ───────────────────
      │                                     │
      ▼                                     ▼
  ┌─────────┐                         ┌─────────┐
  │JS_XS_01 │                         │FL_XS_01 │
  │Type def │                         │Payload  │
  │QRPayload│                         │Model    │
  └────┬────┘                         └─────────┘
       │                                    
       ▼                                    
  ┌─────────┐                               
  │JS_XS_02 │                               
  │signPay- │                               
  │load()   │                               
  └────┬────┘                               
       │                                    
       ▼                                    
  ┌─────────┐                               
  │JS_XS_03 │                               
  │Bridge   │                               
  │Handler  │                               
  └─────────┘                               


PHASE 2: Bridge Layer
═══════════════════════════════════════════════════════════════════════════════

  Requires: JS_XS_03

  ┌─────────┐
  │FL_XS_02 │
  │callJs   │
  │SignPay- │
  │load()   │
  └─────────┘


PHASE 3: Use Case Layer
═══════════════════════════════════════════════════════════════════════════════

  Requires: FL_XS_01, FL_XS_02, M1 IdentityRepository

  ┌─────────┐
  │FL_XS_03 │
  │buildQR  │
  │Payload  │
  │UseCase  │
  └─────────┘


PHASE 4: UI Layer
═══════════════════════════════════════════════════════════════════════════════

  Layout (no dependencies)       Wiring (needs use case)
  ────────────────────────       ───────────────────────
         │                                │
         ▼                                │
    ┌─────────┐                           │
    │FL_XS_04 │                           │
    │QRDisplay│                           │
    │Screen   │                           │
    │Layout   │                           │
    └────┬────┘                           │
         │                                ▼
         │                          ┌─────────┐
         └─────────────────────────▶│FL_XS_05 │ (needs FL_XS_03, FL_XS_04)
                                    │Wire QR  │
                                    │Display  │
                                    └─────────┘


PHASE 5: QA Verification
═══════════════════════════════════════════════════════════════════════════════

  Requires: All implementation tasks complete

    ┌─────────┐
    │QA_XS_01 │
    │QR Gen   │
    │Test     │
    └─────────┘
```

---

## Execution Checklist

### Phase 1: Foundation (Can Run in Parallel)

**Track A: JavaScript Core-Lib**
- [ ] `JS_XS_01` - QRPayloadJson type definition
- [ ] `JS_XS_02` - signPayload() implementation
- [ ] `JS_XS_03` - Bridge handler for payload.sign

**Track B: Flutter Model**
- [ ] `FL_XS_01` - QRPayloadModel with JSON mapping

**Phase 1 Verification:**
- [ ] TypeScript compiles without errors
- [ ] signPayload() can sign test data
- [ ] QRPayloadModel compiles and JSON round-trips correctly

---

### Phase 2: Bridge Layer

**Prerequisites:** JS_XS_03

- [ ] `FL_XS_02` - callJsSignPayload() bridge function

**Phase 2 Verification:**
- [ ] Can call JS bridge and receive signature response
- [ ] Flow events fire correctly

---

### Phase 3: Use Case Layer

**Prerequisites:** FL_XS_01, FL_XS_02, M1 IdentityRepository

- [ ] `FL_XS_03` - buildQRPayloadUseCase()

**Phase 3 Verification:**
- [ ] Use case returns signed QR payload JSON string
- [ ] Returns error when no identity exists
- [ ] Flow events trace complete path

---

### Phase 4: UI Layer

**Layout (No Prerequisites):**
- [ ] `FL_XS_04` - QRDisplayScreen layout

**Wiring (Prerequisites: Use Case + Layout):**
- [ ] `FL_XS_05` - Wire QRDisplayScreen (needs FL_XS_03, FL_XS_04)

**Phase 4 Verification:**
- [ ] Screen renders QR code correctly
- [ ] Loading state displays
- [ ] Error state displays with message
- [ ] QR code is scannable

---

### Phase 5: QA Verification

**Prerequisites:** All implementation complete

- [ ] `QA_XS_01` - Execute QR generation test script

**Phase 5 Verification:**
- [ ] Test script passes
- [ ] Flow events match expected sequence
- [ ] QR payload is valid JSON with all fields

---

## Parallel Execution Guide

If you have multiple agents available:

```
┌─────────────────────────────────────────────────────────────────┐
│  TIME    │  AGENT 1      │  AGENT 2                            │
├──────────┼───────────────┼─────────────────────────────────────┤
│  T+0     │  JS_XS_01     │  FL_XS_01                           │
│  T+1     │  JS_XS_02     │  FL_XS_04 (layout, no deps)         │
│  T+2     │  JS_XS_03     │  (wait for JS_XS_03)                │
│  T+3     │  FL_XS_02     │  (wait for FL_XS_02)                │
│  T+4     │  FL_XS_03     │  (wait for FL_XS_03)                │
│  T+5     │  FL_XS_05     │  (wait for FL_XS_05)                │
│  T+6     │  QA_XS_01     │  -                                  │
└──────────┴───────────────┴─────────────────────────────────────┘
```

---

## Critical Path

The longest dependency chain (critical path) is:

```
JS_XS_01 → JS_XS_02 → JS_XS_03 → FL_XS_02 → FL_XS_03 → FL_XS_05
                                                ↑
                                          FL_XS_01┘
                                                ↑
                                          FL_XS_04┘
```

**Minimum sequential steps:** 6 (if parallelized optimally)

**If running sequentially:** 9 tasks total

---

## Task Summary Table

| Task ID | Description | Dependencies | Est. Time |
|---------|-------------|--------------|-----------|
| JS_XS_01 | QRPayloadJson type | None | 10 min |
| JS_XS_02 | signPayload() | JS_XS_01 | 20 min |
| JS_XS_03 | Bridge handler | JS_XS_02 | 15 min |
| FL_XS_01 | QRPayloadModel | None | 15 min |
| FL_XS_02 | callJsSignPayload | JS_XS_03 | 15 min |
| FL_XS_03 | buildQRPayload UC | FL_XS_01, FL_XS_02 | 25 min |
| FL_XS_04 | QRDisplayScreen | None | 20 min |
| FL_XS_05 | Wire QRDisplay | FL_XS_03, FL_XS_04 | 20 min |
| QA_XS_01 | Test script | All above | 15 min |

**Total estimated time:** ~2.5 hours (sequential), ~1.5 hours (parallel)
