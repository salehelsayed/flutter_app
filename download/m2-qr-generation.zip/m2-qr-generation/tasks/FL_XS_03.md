# Task Prompt: FL_XS_03 - buildQRPayload Use Case

## Instructions for AI Agent

You are implementing a specific task for a Flutter/JS application. Follow the task specification exactly. Output complete, working code that can be directly used.

---

## Global Context

```
Milestone: M2 – QR Code Generation

Use Case Requirements:
  1. Load identity from repository
  2. Build unsigned payload (pk, ns, rv, ts)
  3. Serialize to canonical JSON
  4. Call JS bridge to sign
  5. Add signature to payload
  6. Return final JSON string for QR

Constants:
  RENDEZVOUS_ADDRESS = '/dns4/mknoun.xyz/tcp/4001/wss/p2p/12D3KooWGMYMmN1RGUYjWaSV6P3XtnBjwnosnJGNMnttfVCRnd6g'

Existing Components (from M1):
  - IdentityRepository with loadIdentity() returning IdentityModel?
  - IdentityModel with peerId, publicKey, privateKey fields

New Components (from M2):
  - QRPayloadModel with buildUnsignedPayload() and toJsonString()
  - callJsSignPayload() bridge function
```

---

## Task Definition

```
[TASK FL_XS_03 – buildQRPayloadUseCase()]

Owner: Flutter

Goal:
  Orchestrate building a signed QR payload from identity data.

What to implement:
  - enum BuildQRPayloadResult {
      success,
      noIdentity,
      signingError,
    }

  - Function signature:
      Future<(BuildQRPayloadResult, String?)> buildQRPayload({
        required IdentityRepository repo,
        required Future<Map<String, dynamic>> Function({
          required String dataToSign,
          required String privateKey,
        }) callJsSign,
      })

  - Logic:
      1. Load identity from repo
      2. If null → return (noIdentity, null)
      3. Build unsigned payload:
         - pk = identity.publicKey
         - ns = identity.peerId
         - rv = RENDEZVOUS_ADDRESS constant
         - ts = current UTC timestamp
      4. Serialize unsigned payload to canonical JSON
      5. Call JS bridge to sign
      6. If signing fails → return (signingError, null)
      7. Add signature to payload
      8. Return (success, finalJsonString)

Inputs:
  - IdentityRepository repo
  - callJsSign: Function to call JS bridge for signing

Outputs:
  - Tuple of (BuildQRPayloadResult, String?)
  - On success: (success, "{"ns":"...","pk":"...","rv":"...","sig":"...","ts":"..."}")
  - On no identity: (noIdentity, null)
  - On signing error: (signingError, null)

Flow_events:
  - At start:
      - layer: "FL", event: "QR_FL_BUILD_PAYLOAD_START", details: {}
  - After loading identity - found:
      - layer: "FL", event: "QR_FL_BUILD_PAYLOAD_IDENTITY_FOUND", details: { "peerId": truncated }
  - After loading identity - not found:
      - layer: "FL", event: "QR_FL_BUILD_PAYLOAD_NO_IDENTITY", details: {}
  - Before signing:
      - layer: "FL", event: "QR_FL_BUILD_PAYLOAD_SIGNING", details: {}
  - After signing - success:
      - layer: "FL", event: "QR_FL_BUILD_PAYLOAD_SUCCESS", details: {}
  - After signing - error:
      - layer: "FL", event: "QR_FL_BUILD_PAYLOAD_SIGN_ERROR", details: { "errorCode": "..." }

Constraints:
  - Dependency injection for testability
  - Use canonical JSON (sorted keys) for signing
  - Do not store or persist the QR payload
  - Return the raw JSON string (UI will render QR)

Deliverable:
  - File: lib/features/qr_code/application/build_qr_payload_use_case.dart
```

---

## Output Requirements

1. **File:** `lib/features/qr_code/application/build_qr_payload_use_case.dart`

2. **Must include:**
   - `BuildQRPayloadResult` enum
   - `buildQRPayload()` function
   - Flow event emissions
   - Proper error handling
   - Use of RENDEZVOUS_ADDRESS constant

3. **Implementation:**

```dart
import 'dart:convert';
import 'dart:collection';

import 'package:your_app/core/constants/network_constants.dart';
import 'package:your_app/core/utils/flow_event_emitter.dart';
import 'package:your_app/features/identity/domain/repositories/identity_repository.dart';

/// Result of building a QR payload
enum BuildQRPayloadResult {
  /// Successfully built and signed the payload
  success,
  
  /// No identity found in repository
  noIdentity,
  
  /// Signing operation failed
  signingError,
}

/// Builds a signed QR payload containing the user's identity information.
/// 
/// The payload includes:
/// - pk: Public key (base64)
/// - ns: Namespace (peerID)
/// - rv: Rendezvous address
/// - ts: Timestamp
/// - sig: Ed25519 signature
/// 
/// Returns a tuple of (result, jsonString?).
/// On success, jsonString contains the canonical JSON ready for QR encoding.
Future<(BuildQRPayloadResult, String?)> buildQRPayload({
  required IdentityRepository repo,
  required Future<Map<String, dynamic>> Function({
    required String dataToSign,
    required String privateKey,
  }) callJsSign,
}) async {
  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BUILD_PAYLOAD_START',
    details: {},
  );

  // 1. Load identity
  final identity = await repo.loadIdentity();
  
  if (identity == null) {
    emitFlowEvent(
      layer: 'FL',
      event: 'QR_FL_BUILD_PAYLOAD_NO_IDENTITY',
      details: {},
    );
    return (BuildQRPayloadResult.noIdentity, null);
  }

  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BUILD_PAYLOAD_IDENTITY_FOUND',
    details: {'peerId': identity.peerId.substring(0, 12)},
  );

  // 2. Build unsigned payload
  final timestamp = DateTime.now().toUtc().toIso8601String();
  final unsignedPayload = SplayTreeMap<String, dynamic>.from({
    'ns': identity.peerId,
    'pk': identity.publicKey,
    'rv': RENDEZVOUS_ADDRESS,
    'ts': timestamp,
  });

  // 3. Serialize to canonical JSON (sorted keys, no extra whitespace)
  final dataToSign = jsonEncode(unsignedPayload);

  // 4. Call JS bridge to sign
  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BUILD_PAYLOAD_SIGNING',
    details: {},
  );

  final signResponse = await callJsSign(
    dataToSign: dataToSign,
    privateKey: identity.privateKey,
  );

  // 5. Check signing result
  if (signResponse['ok'] != true) {
    final errorCode = signResponse['errorCode'] ?? 'UNKNOWN';
    emitFlowEvent(
      layer: 'FL',
      event: 'QR_FL_BUILD_PAYLOAD_SIGN_ERROR',
      details: {'errorCode': errorCode},
    );
    return (BuildQRPayloadResult.signingError, null);
  }

  // 6. Add signature to payload
  final signature = signResponse['signature'] as String;
  final signedPayload = SplayTreeMap<String, dynamic>.from({
    ...unsignedPayload,
    'sig': signature,
  });

  // 7. Serialize final payload
  final finalJson = jsonEncode(signedPayload);

  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BUILD_PAYLOAD_SUCCESS',
    details: {},
  );

  return (BuildQRPayloadResult.success, finalJson);
}
```

---

## Constants File

Create or verify this file exists:

```dart
// lib/core/constants/network_constants.dart

/// Rendezvous point for P2P connections
const String RENDEZVOUS_ADDRESS = 
    '/dns4/mknoun.xyz/tcp/4001/wss/p2p/12D3KooWGMYMmN1RGUYjWaSV6P3XtnBjwnosnJGNMnttfVCRnd6g';
```

---

## Usage Example

```dart
// In a widget or controller
final (result, qrString) = await buildQRPayload(
  repo: identityRepository,
  callJsSign: ({required dataToSign, required privateKey}) => 
      bridgeClient.callJsSignPayload(
        dataToSign: dataToSign,
        privateKey: privateKey,
      ),
);

switch (result) {
  case BuildQRPayloadResult.success:
    // qrString contains the JSON to encode in QR
    showQRCode(qrString!);
    break;
  case BuildQRPayloadResult.noIdentity:
    showError('No identity found. Please create one first.');
    break;
  case BuildQRPayloadResult.signingError:
    showError('Failed to sign QR payload. Please try again.');
    break;
}
```

---

## Test Cases

```dart
// Test with mock
void testBuildQRPayload() async {
  // Mock repository
  final mockRepo = MockIdentityRepository();
  when(mockRepo.loadIdentity()).thenAnswer((_) async => IdentityModel(
    peerId: '12D3KooWTest...',
    publicKey: 'dGVzdC1wdWJsaWMta2V5',
    privateKey: 'dGVzdC1wcml2YXRlLWtleQ==',
    mnemonic12: 'word1 word2 ...',
    createdAt: '2025-01-01T00:00:00Z',
    updatedAt: '2025-01-01T00:00:00Z',
  ));

  // Mock signing
  Future<Map<String, dynamic>> mockSign({
    required String dataToSign,
    required String privateKey,
  }) async {
    return {'ok': true, 'signature': 'bW9jay1zaWduYXR1cmU='};
  }

  final (result, qrString) = await buildQRPayload(
    repo: mockRepo,
    callJsSign: mockSign,
  );

  expect(result, BuildQRPayloadResult.success);
  expect(qrString, isNotNull);
  
  final parsed = jsonDecode(qrString!);
  expect(parsed['pk'], 'dGVzdC1wdWJsaWMta2V5');
  expect(parsed['ns'], '12D3KooWTest...');
  expect(parsed['rv'], contains('mknoun.xyz'));
  expect(parsed['sig'], 'bW9jay1zaWduYXR1cmU=');
}
```

---

## Begin Implementation

Output the complete Dart file with the use case function and enum.
