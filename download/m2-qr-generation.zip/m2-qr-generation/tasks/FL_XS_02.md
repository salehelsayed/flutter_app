# Task Prompt: FL_XS_02 - callJsSignPayload() Bridge Function

## Instructions for AI Agent

You are implementing a specific task for a Flutter/JS application. Follow the task specification exactly. Output complete, working code that can be directly used.

---

## Global Context

```
Milestone: M2 – QR Code Generation

Bridge Contract for payload.sign:
  Request:
    {
      "cmd": "payload.sign",
      "payload": {
        "dataToSign": "canonical-json-string",
        "privateKey": "base64-encoded-private-key"
      }
    }

  Success Response:
    {
      "ok": true,
      "signature": "base64-encoded-signature"
    }

  Error Response:
    {
      "ok": false,
      "errorCode": "SIGNING_ERROR" | "INVALID_PRIVATE_KEY" | "INTERNAL_ERROR",
      "errorMessage": "Description of what went wrong"
    }

Existing Infrastructure (from M1):
  - JsBridge class with sendMessage() method
  - Message encoding/decoding
  - Async response handling
```

---

## Task Definition

```
[TASK FL_XS_02 – callJsSignPayload() bridge client function]

Owner: Flutter

Goal:
  Provide a Flutter function to call the JS payload.sign command via bridge.

What to implement:
  - Function signature:
      Future<Map<String, dynamic>> callJsSignPayload({
        required JsBridge bridge,
        required String dataToSign,
        required String privateKey,
      })
  
  - Or as a method on JsBridgeClient class:
      Future<Map<String, dynamic>> callJsSignPayload({
        required String dataToSign,
        required String privateKey,
      })
  
  - Behavior:
      1. Emit flow event: request
      2. Build message: { "cmd": "payload.sign", "payload": {...} }
      3. Send via bridge
      4. Emit flow event: response
      5. Return decoded response map

Inputs:
  - bridge: JsBridge instance (or use instance variable if method)
  - dataToSign: String - The canonical JSON string to sign
  - privateKey: String - Base64-encoded private key from identity

Outputs:
  - Map<String, dynamic> with response:
      - On success: { "ok": true, "signature": "base64..." }
      - On error: { "ok": false, "errorCode": "...", "errorMessage": "..." }

Flow_events:
  - Before sending:
      - layer: "FL"
      - event: "QR_FL_BRIDGE_SIGN_REQUEST"
      - details: { "dataLength": dataToSign.length }
  - After receiving:
      - layer: "FL"
      - event: "QR_FL_BRIDGE_SIGN_RESPONSE"
      - details: { "ok": response.ok }

Constraints:
  - Does not interpret success/error, just returns response map
  - Follows existing M1 bridge client patterns
  - This is an ADDITION to js_bridge_client.dart

Deliverable:
  - Addition to: lib/core/bridge/js_bridge_client.dart
```

---

## Output Requirements

1. **File:** `lib/core/bridge/js_bridge_client.dart` (addition to existing file)

2. **Must include:**
   - The `callJsSignPayload` method
   - Flow event emissions
   - Proper message format
   - Response handling

3. **Implementation (as class method):**

```dart
// Add this method to existing JsBridgeClient class

/// Calls the JS bridge to sign payload data with Ed25519.
/// 
/// [dataToSign] - The canonical JSON string to sign
/// [privateKey] - Base64-encoded Ed25519 private key
/// 
/// Returns a map with:
/// - On success: { "ok": true, "signature": "base64..." }
/// - On error: { "ok": false, "errorCode": "...", "errorMessage": "..." }
Future<Map<String, dynamic>> callJsSignPayload({
  required String dataToSign,
  required String privateKey,
}) async {
  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BRIDGE_SIGN_REQUEST',
    details: {'dataLength': dataToSign.length},
  );

  final message = {
    'cmd': 'payload.sign',
    'payload': {
      'dataToSign': dataToSign,
      'privateKey': privateKey,
    },
  };

  final response = await _sendMessage(message);

  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BRIDGE_SIGN_RESPONSE',
    details: {'ok': response['ok'] ?? false},
  );

  return response;
}
```

4. **Alternative (as standalone function):**

```dart
/// Calls the JS bridge to sign payload data with Ed25519.
Future<Map<String, dynamic>> callJsSignPayload({
  required JsBridge bridge,
  required String dataToSign,
  required String privateKey,
}) async {
  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BRIDGE_SIGN_REQUEST',
    details: {'dataLength': dataToSign.length},
  );

  final message = {
    'cmd': 'payload.sign',
    'payload': {
      'dataToSign': dataToSign,
      'privateKey': privateKey,
    },
  };

  final response = await bridge.sendMessage(message);

  emitFlowEvent(
    layer: 'FL',
    event: 'QR_FL_BRIDGE_SIGN_RESPONSE',
    details: {'ok': response['ok'] ?? false},
  );

  return response;
}
```

---

## Integration with Existing M1 Bridge Client

The JsBridgeClient class should now have:

```dart
// lib/core/bridge/js_bridge_client.dart

import 'dart:convert';
import 'package:your_app/core/utils/flow_event_emitter.dart';

class JsBridgeClient {
  // ... existing bridge setup code ...

  // ============================================
  // M1 METHODS (existing)
  // ============================================

  /// Calls JS to generate a new identity
  Future<Map<String, dynamic>> callJsIdentityGenerate() async {
    // ... existing M1 implementation
  }

  /// Calls JS to restore identity from mnemonic
  Future<Map<String, dynamic>> callJsIdentityRestore(String mnemonic12) async {
    // ... existing M1 implementation
  }

  // ============================================
  // M2 METHODS (new)
  // ============================================

  /// Calls JS to sign payload data with Ed25519
  Future<Map<String, dynamic>> callJsSignPayload({
    required String dataToSign,
    required String privateKey,
  }) async {
    // ... new implementation from this task
  }
}
```

---

## Flow Event Helper

Assume this exists (from M1):

```dart
void emitFlowEvent({
  required String layer,
  required String event,
  required Map<String, dynamic> details,
}) {
  final payload = {
    'ts': DateTime.now().toUtc().toIso8601String(),
    'milestone': 'M2_QR_GENERATION',
    'layer': layer,
    'event': event,
    'details': details,
  };
  print('[FLOW] ${jsonEncode(payload)}');
}
```

---

## Usage Example

```dart
// In use case or other calling code
final bridgeClient = JsBridgeClient();

final response = await bridgeClient.callJsSignPayload(
  dataToSign: '{"ns":"12D3KooW...","pk":"SGVsbG8=","rv":"/dns4/...","ts":"2025-01-22T00:00:00Z"}',
  privateKey: 'BASE64_PRIVATE_KEY_FROM_IDENTITY',
);

if (response['ok'] == true) {
  final signature = response['signature'] as String;
  print('Got signature: $signature');
} else {
  final errorCode = response['errorCode'] as String;
  final errorMessage = response['errorMessage'] as String;
  print('Signing failed: $errorCode - $errorMessage');
}
```

---

## Begin Implementation

Output the code that should be ADDED to the existing js_bridge_client.dart file. Show the complete method implementation.
