# M2 Verification Checklist

Use this checklist to verify each task output before moving to dependent tasks.

---

## How to Use

1. After running a task, check all items in that task's section
2. If any check fails, fix before proceeding
3. Mark the task complete only when ALL checks pass
4. Integration checks should be done after each phase

---

## Task Verification

### JS_XS_01 - QRPayloadJson Type Definition

- [ ] **File exists:** `core_lib_js/src/types/qr_payload.ts`
- [ ] **UnsignedQRPayload interface defined:**
  - [ ] `pk: string` (public key)
  - [ ] `ns: string` (namespace)
  - [ ] `rv: string` (rendezvous)
  - [ ] `ts: string` (timestamp)
- [ ] **SignedQRPayload interface defined:**
  - [ ] Extends UnsignedQRPayload
  - [ ] `sig: string` (signature)
- [ ] **Exported:** Both interfaces are exported
- [ ] **TypeScript compiles:** No type errors

```typescript
// Quick test
import { UnsignedQRPayload, SignedQRPayload } from './qr_payload';

const unsigned: UnsignedQRPayload = {
  pk: 'test',
  ns: 'test',
  rv: 'test',
  ts: new Date().toISOString(),
};

const signed: SignedQRPayload = {
  ...unsigned,
  sig: 'test-signature',
};
```

---

### JS_XS_02 - signPayload() Implementation

- [ ] **File exists:** `core_lib_js/src/signing/sign_payload.ts`
- [ ] **Function signature:** `async function signPayload(dataToSign: string, privateKeyBase64: string): Promise<string>`
- [ ] **Uses Ed25519:** Proper crypto library imported
- [ ] **Decodes private key:** From base64 correctly
- [ ] **Signs UTF-8 bytes:** Of the dataToSign string
- [ ] **Returns base64 signature:** Properly encoded
- [ ] **Flow events:**
  - [ ] Emits `QR_JS_SIGN_PAYLOAD_START`
  - [ ] Emits `QR_JS_SIGN_PAYLOAD_SUCCESS` or `QR_JS_SIGN_PAYLOAD_ERROR`
- [ ] **Error handling:** Catches and rethrows with context

```typescript
// Quick test
const testPrivateKey = 'base64-encoded-ed25519-private-key';
const testData = '{"pk":"test","ns":"test","rv":"test","ts":"2025-01-01T00:00:00Z"}';

const sig = await signPayload(testData, testPrivateKey);
console.log(sig); // Should be base64 string
```

---

### JS_XS_03 - Bridge Handler for payload.sign

- [ ] **Handler registered:** `payload.sign` in handlers map
- [ ] **Extracts parameters:**
  - [ ] `dataToSign` from payload
  - [ ] `privateKey` from payload
- [ ] **Calls signPayload:** With extracted parameters
- [ ] **Success response:**
  ```json
  { "ok": true, "signature": "base64..." }
  ```
- [ ] **Error response:**
  ```json
  { "ok": false, "errorCode": "SIGNING_ERROR", "errorMessage": "..." }
  ```
- [ ] **Flow events:**
  - [ ] Emits `QR_JS_BRIDGE_SIGN_RECEIVED`
  - [ ] Emits `QR_JS_BRIDGE_SIGN_SUCCESS` or `QR_JS_BRIDGE_SIGN_ERROR`

```typescript
// Quick test
const request = {
  cmd: 'payload.sign',
  payload: {
    dataToSign: '{"pk":"test"}',
    privateKey: 'base64-private-key',
  },
};
const response = await handleBridgeMessage(request);
console.log(response.ok); // true or false
```

---

### FL_XS_01 - QRPayloadModel

- [ ] **Class exists:** `QRPayloadModel`
- [ ] **All fields present:**
  - [ ] `String pk`
  - [ ] `String ns`
  - [ ] `String rv`
  - [ ] `String ts`
  - [ ] `String sig`
- [ ] **Immutable:** All fields are `final`
- [ ] **fromJson works:** Factory constructor accepts `Map<String, dynamic>`
- [ ] **toJson works:** Returns `Map<String, dynamic>` with correct keys
- [ ] **toJsonString works:** Returns canonical JSON string (sorted keys)
- [ ] **Round-trip test passes:**

```dart
final json = {
  'pk': 'public-key-base64',
  'ns': '12D3KooW...',
  'rv': '/dns4/mknoun.xyz/...',
  'ts': '2025-01-22T12:00:00.000Z',
  'sig': 'signature-base64',
};
final model = QRPayloadModel.fromJson(json);
final back = model.toJson();
assert(back['pk'] == json['pk']);
// ... all fields match
```

---

### FL_XS_02 - callJsSignPayload()

- [ ] **Function exists:** In `JsBridgeClient` or standalone
- [ ] **Function signature:**
  ```dart
  Future<Map<String, dynamic>> callJsSignPayload({
    required String dataToSign,
    required String privateKey,
  })
  ```
- [ ] **Sends correct message:**
  ```json
  { "cmd": "payload.sign", "payload": { "dataToSign": "...", "privateKey": "..." } }
  ```
- [ ] **Returns decoded response:** Map with `ok`, `signature` or `errorCode`
- [ ] **Flow events:**
  - [ ] Emits `QR_FL_BRIDGE_SIGN_REQUEST`
  - [ ] Emits `QR_FL_BRIDGE_SIGN_RESPONSE`

---

### FL_XS_03 - buildQRPayloadUseCase()

- [ ] **Enum exists:**
  ```dart
  enum BuildQRPayloadResult { success, noIdentity, signingError }
  ```
- [ ] **Function signature:**
  ```dart
  Future<(BuildQRPayloadResult, String?)> buildQRPayload({
    required IdentityRepository repo,
    required Future<Map<String, dynamic>> Function(String, String) callJsSign,
  })
  ```
- [ ] **Logic flow:**
  - [ ] Loads identity from repo
  - [ ] Returns `noIdentity` if null
  - [ ] Builds unsigned payload with pk, ns, rv, ts
  - [ ] Serializes to canonical JSON (sorted keys)
  - [ ] Calls JS sign with data and privateKey
  - [ ] Returns `signingError` if signing fails
  - [ ] Adds signature to payload
  - [ ] Returns `success` with final JSON string
- [ ] **Uses RENDEZVOUS_ADDRESS constant**
- [ ] **Flow events:**
  - [ ] Emits `QR_FL_BUILD_PAYLOAD_START`
  - [ ] Emits appropriate result events

```dart
// Quick test with mock
final result = await buildQRPayload(
  repo: mockRepo,
  callJsSign: (data, key) async => {'ok': true, 'signature': 'test-sig'},
);
assert(result.$1 == BuildQRPayloadResult.success);
assert(result.$2 != null);
final parsed = jsonDecode(result.$2!);
assert(parsed['sig'] == 'test-sig');
```

---

### FL_XS_04 - QRDisplayScreen Layout

- [ ] **Widget exists:** `QRDisplayScreen`
- [ ] **Constructor parameters:**
  - [ ] `String qrData` (the JSON string)
  - [ ] `String peerId` (for display)
  - [ ] `VoidCallback onClose`
  - [ ] `VoidCallback? onShare` (optional)
- [ ] **UI elements:**
  - [ ] AppBar with back/close button
  - [ ] Title "My QR Code"
  - [ ] QR code widget (256x256 minimum)
  - [ ] Instruction text "Scan to connect with me"
  - [ ] Truncated peerId display
  - [ ] Share button (if onShare provided)
- [ ] **No business logic:** Pure layout
- [ ] **Uses qr_flutter package:** `QrImageView` widget

```dart
// Quick test
QRDisplayScreen(
  qrData: '{"pk":"test"}',
  peerId: '12D3KooWAbcdef...',
  onClose: () {},
);
// Should render without errors
```

---

### FL_XS_05 - Wire QRDisplayScreen

- [ ] **Widget exists:** `QRDisplayWired`
- [ ] **Calls buildQRPayload:** On initialization
- [ ] **Handles all states:**
  - [ ] Loading: Shows CircularProgressIndicator
  - [ ] Success: Shows QRDisplayScreen with data
  - [ ] noIdentity: Shows error message
  - [ ] signingError: Shows error message with retry
- [ ] **Dependencies injected:** Repository and bridge function
- [ ] **Flow events:**
  - [ ] Emits `QR_FL_SCREEN_INIT`
  - [ ] Emits `QR_FL_SCREEN_DISPLAY` on success
  - [ ] Emits `QR_FL_SCREEN_ERROR` on error

---

### QA_XS_01 - QR Generation Test Script

- [ ] **File exists:** `docs/qa/QA_M2_XS_01_qr_generation.md`
- [ ] **Prerequisites listed:** Identity must exist (M1 complete)
- [ ] **Test steps complete:**
  - [ ] Navigate to QR screen
  - [ ] Verify loading state
  - [ ] Verify QR displays
  - [ ] Verify peerId shown
  - [ ] Scan QR and verify payload
- [ ] **Expected flow events listed**
- [ ] **Pass/fail criteria clear**

---

## Integration Verification

### After Phase 1

```typescript
// Test: JS types + signing
import { UnsignedQRPayload } from './types/qr_payload';
import { signPayload } from './signing/sign_payload';

const payload: UnsignedQRPayload = {
  pk: 'test-pk',
  ns: 'test-ns',
  rv: '/dns4/test',
  ts: new Date().toISOString(),
};

const data = JSON.stringify(payload);
const sig = await signPayload(data, testPrivateKey);
console.log('Signature:', sig);
```

### After Phase 2

```dart
// Test: Bridge round-trip
final response = await callJsSignPayload(
  dataToSign: '{"test":"data"}',
  privateKey: 'test-private-key-base64',
);
print(response); // {ok: true/false, ...}
```

### After Phase 3

```dart
// Test: Use case end-to-end
final (result, qrString) = await buildQRPayload(
  repo: realRepo,
  callJsSign: realBridgeFunction,
);
if (result == BuildQRPayloadResult.success) {
  final payload = jsonDecode(qrString!);
  print('PK: ${payload['pk']}');
  print('NS: ${payload['ns']}');
  print('RV: ${payload['rv']}');
  print('TS: ${payload['ts']}');
  print('SIG: ${payload['sig']}');
}
```

### After Phase 4

```
// Test: Full UI flow
1. Ensure identity exists (M1 complete)
2. Navigate to QR display screen
3. Verify loading spinner appears briefly
4. Verify QR code renders
5. Verify peerId shown below QR
6. Use another device/app to scan QR
7. Verify scanned payload is valid JSON
8. Verify all fields present: pk, ns, rv, ts, sig
```

---

## QR Payload Validation

After generating a QR, scan it and verify:

- [ ] **Valid JSON:** Parses without error
- [ ] **pk field:** Base64 string, matches identity.publicKey
- [ ] **ns field:** String, matches identity.peerId
- [ ] **rv field:** Equals `/dns4/mknoun.xyz/tcp/4001/wss/p2p/12D3KooWGMYMmN1RGUYjWaSV6P3XtnBjwnosnJGNMnttfVCRnd6g`
- [ ] **ts field:** Valid ISO-8601 timestamp
- [ ] **sig field:** Base64 string, non-empty

```json
// Example valid payload
{
  "pk": "SGVsbG8gV29ybGQhIFRoaXMgaXMgYSB0ZXN0Lg==",
  "ns": "12D3KooWA1b2C3d4E5f6G7h8I9j0K1L2M3N4O5P6",
  "rv": "/dns4/mknoun.xyz/tcp/4001/wss/p2p/12D3KooWGMYMmN1RGUYjWaSV6P3XtnBjwnosnJGNMnttfVCRnd6g",
  "ts": "2025-01-22T15:30:00.000Z",
  "sig": "U2lnbmF0dXJlQmFzZTY0RW5jb2RlZFN0cmluZw=="
}
```

---

## Final Sign-Off

- [ ] All 9 tasks verified individually
- [ ] All integration checks pass
- [ ] QA_XS_01 test script passes
- [ ] QR code is scannable
- [ ] Scanned payload contains all required fields
- [ ] Flow events trace complete path
- [ ] No console errors or warnings
- [ ] UI matches design guidelines (centered QR, chat-app style)

**M2 QR Code Generation: COMPLETE**

Signed: _______________ Date: _______________
